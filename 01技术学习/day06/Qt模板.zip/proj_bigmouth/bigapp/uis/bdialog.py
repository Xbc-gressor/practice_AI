from PyQt5.QtWidgets import QDialog

class BDialog(QDialog):
    def __init__(self):
        super(BDialog, self).__init__()
    