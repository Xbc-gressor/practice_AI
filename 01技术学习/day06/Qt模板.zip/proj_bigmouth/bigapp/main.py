from bigapp.uis.bapp import BApp

app = BApp()
app.exec()
